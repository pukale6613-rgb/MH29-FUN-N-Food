import json,re,datetime,urllib.request
from html import unescape
URL="https://in.bookmyshow.com/cinemas/yavatmal/mh29-fun-n-food-miniplex-yavatmal/buytickets/MHFF/"
req=urllib.request.Request(URL,headers={"User-Agent":"Mozilla/5.0"})
html=urllib.request.urlopen(req,timeout=30).read().decode("utf-8","ignore")
# This updater is intentionally conservative: it only writes titles/times it can clearly identify.
# If BookMyShow changes its markup, the existing JSON remains in place rather than being erased.
patterns=[r'([A-Z][A-Za-z0-9: .\-’']{1,70})\s*\((?:UA\d*\+?|U|A)\)',r'([A-Z][A-Za-z0-9: .\-’']{1,70})\s*<']
found=[]
for p in patterns:
  for m in re.findall(p,html):
    t=unescape(re.sub(r'\s+',' ',m)).strip()
    if t and t not in found and len(t)<80: found.append(t)
if not found:
  raise SystemExit("No safe movie titles found; keeping previous data")
old=json.load(open("cinema-data.json",encoding="utf-8"))
old["updatedAt"]=datetime.datetime.now(datetime.timezone.utc).isoformat()
old["source"]=URL
# Preserve known showtimes when the upstream page cannot be parsed reliably.
old["movies"]=[{"title":t,"language":"","showtimes":[]} for t in found]
json.dump(old,open("cinema-data.json","w",encoding="utf-8"),ensure_ascii=False,indent=2)
